import {combineReducers} from 'redux';
import reducer from './reducers';
const reduc=combineReducers({
    reducer
}

);

export default reduc;